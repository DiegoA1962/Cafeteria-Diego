# jonnys coffe


O meu software foi desenvolvido para facilitar a visualização do cardápio de uma cafeteria! ☕🍰 Ele permite que os clientes explorem as opções de bebidas e alimentos de maneira simples e interativa. 
🍩 Com uma interface amigável, você pode ver desde cafés quentinhos ☕ até doces deliciosos 🍪 e salgados crocantes 🥐. Tudo isso com a possibilidade de atualizar facilmente o cardápio e escolher o 
que mais agrada! 😋 Ideal para quem busca praticidade e sabor em um só lugar.
